/*
A simple LoadRunner script template that can be used to deploy files, run command line or silent install using a LoadRunner agent

Files included in the template:
	7za.exe			a command line executable used to create or decompression archive files
	bitsadmin.exe	a command line executable - Background Intelligent Transfer Service (BITS) transfers files (downloads or uploads) between a client and server and provides progress information related to the transfers. You can also download files from a peer.
	commandLine.bat	a command line batch file to execute your commands such as decompress or execute
