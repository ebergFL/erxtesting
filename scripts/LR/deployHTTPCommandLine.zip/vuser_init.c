vuser_init()
{
	system("copy commandLine.txt commandLine.bat >> c:\\commandLine.log");
	system("commandLine.bat >> c:\\commandLine.log");

	return 0;
}
